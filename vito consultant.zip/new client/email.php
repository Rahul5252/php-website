 <?php
     if (isset($_POST['submit'])) {
        $name = $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $contact = $_REQUEST['contact'];
        $message = $_REQUEST['message'];

      // Set your email address where you want to receive emails. 
       $to = 'prettifycreative@gmail.com';
       $subject = 'Contact Request From Website';
       $headers = "From: ".$name." ".$contact." <".$email."> \r\n";
       $send_email = mail($to,$subject,$message,$headers);

       echo ($send_email) ? 'success' : 'error';

  }?>